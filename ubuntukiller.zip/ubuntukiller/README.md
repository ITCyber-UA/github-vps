# ubuntukiller
* Go to -> https://killercoda.com/pawelpiwosz/course/linuxFundamentals/lf-21-finalTest
```
git clone https://github.com/a2nk/ubuntukiller
```
```
cd ubuntukiller
```
```
chmod a+x start.sh ngrok.sh
```
```
./start.sh
```
```
./ngrok.sh
```
