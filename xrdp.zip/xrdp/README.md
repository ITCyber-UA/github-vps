# lxde-vnc
* Copy + Paste this git repositories to get Free XRDP Browser (lxde-vnc) on Okteto Cloud:
```
https://github.com/a2nk/xrdp
```
* How to use-> https://aank.me/Youtube
