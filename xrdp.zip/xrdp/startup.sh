#!/bin/bash
# Free XRDP Aank is ME
service ssh start
service nginx start
